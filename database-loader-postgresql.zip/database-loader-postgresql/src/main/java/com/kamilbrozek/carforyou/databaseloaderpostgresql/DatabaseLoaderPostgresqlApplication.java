package com.kamilbrozek.carforyou.databaseloaderpostgresql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseLoaderPostgresqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseLoaderPostgresqlApplication.class, args);
	}

}
